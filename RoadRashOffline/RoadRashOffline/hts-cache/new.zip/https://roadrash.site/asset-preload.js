<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>Page not found – RoadRash Classic</title>
<link rel="icon" type="image/png" sizes="64x64" href="/favicon-classic.png?v=rider-1">
<style>html,body{margin:0;height:100%;background:#0d0d0b;color:#e9efe6;font:18px/1.5 system-ui,sans-serif}main{min-height:100%;display:grid;place-content:center;gap:8px;padding:24px;text-align:center;box-sizing:border-box}h1{margin:0;color:#ff5e2a;font-size:40px}a{color:#f8f078}</style>
</head>
<body>
<main>
  <h1>Wrong turn</h1>
  <p>This page doesn't exist.</p>
  <p><a href="/">Play RoadRash Classic online</a> · <a href="/how-to-play-road-rash/">How to play</a></p>
</main>
</body>
</html>
